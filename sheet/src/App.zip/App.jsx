import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";

import "./App.css";

import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import Operation from "./components/Operation";
import Analytics from "./components/Analytics";
import Team from "./components/Team"; // Team Management Page component
import Profile from "./components/Profile";

// ================= Initial Tasks =================

const initialTasks = [
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Re: Intellectt Inc ( AI & Generative AI Training )- SSDN Technologies",
    timing: "10:33 AM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Amit",
    task: "Re: Exploring Collaboration Opportunities with Kaplan ME +MOM",
    timing: "11:17 AM",
    remarks: "Closed",
    completedTime: "4:30 PM",
    completedDate: "01-07-2026",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Re: Proposal : Questionnaire_RE: SSDN Technologies_Beyond Codes Discussion",
    timing: "11:56 AM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Re: [ENQUIRY] Hawksford ( Microsoft Copilot Training ) || SSDN Technologies",
    timing: "12:02 PM",
    remarks: "In-Process",
    completedTime: "Reply (8:51 AM",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Amit",
    task: "Re: Exploring Collaboration Opportunity | SSDN Technologies & LeadSpire Consulting",
    timing: "12:46 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Shivam",
    task: "RE: Issue with LAB",
    timing: "12:57 PM",
    remarks: "Respond Share",
    completedTime: "1:15 PM",
    completedDate: "01-07-2026",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Zaptas Technologies Pvt Ltd. ( Microsoft ) || SSDN Technologies",
    timing: "1:07 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Re: [External] Re: Buckman Laboratories ( Lean six sigma black belt ) – SSDN Technologies",
    timing: "1:23 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Shivam",
    task: "Re: [External] Re: Buckman Laboratories ( Lean six sigma black belt ) – SSDN Technologies",
    timing: "1:33 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Kamal",
    task: "Re: Training+Lab and Extended Lab Requirement | Citrix VDI AVD L2 - AMJ'26",
    timing: "2:17 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "3:38 PM",
    completedDate: "01-07-2026",
  },
  {
    date: "01-07-2026",
    name: "Shivam",
    task: "Facing in Lab Environment – Impact on Training Activities By Gorantla",
    timing: "2:47 PM",
    remarks: "Respond Share",
    completedTime: "4:21 PM",
    completedDate: "01-07-2026",
  },
  {
    date: "01-07-2026",
    name: "Shivam",
    task: "Facing in Lab Environment – Impact on Training Activities By",
    timing: "3:02 PM",
    remarks: "Respond Share",
    completedTime: "4:24 PM",
    completedDate: "01-07-2026",
  },
  {
    date: "01-07-2026",
    name: "Kamal",
    task: "Re: IBM BAW Training",
    timing: "3:20 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Amit",
    task: "Business Collaboration Call with Kaplan ME || SSDN Technologies (Amit, Mukesh, Srishti, Shivam)",
    timing: "3:00 PM",
    remarks: "CALL",
    completedTime: "3:25 PM",
    completedDate: "01-07-2026",
  },
  {
    date: "01-07-2026",
    name: "Shivam",
    task: "Re: Request for Extended Labs | SCCM + Intune L2 (Batch 1) 19 June-20 July'26",
    timing: "3:26 PM",
    remarks: "Solution",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Landmark Group ( Cloudflare Training ) || SSDN Technologies",
    timing: "3:56 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Kanika",
    task: "Re: AI & Generative AI- Training Requirement",
    timing: "4:27 PM",
    remarks: "Closed",
    completedTime: "6:30 PM",
    completedDate: "01-07-2026",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Kion Group ( OT Security Course (SCADA, PLCs) Training ) || SSDN Technologies",
    timing: "4:46 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Amit",
    task: "Re: Exploring Collaboration Opportunities with Kaplan ME",
    timing: "5:10 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Re: Generative AI Trainer Requirement – Finance & Procurement | SSDN Technologies",
    timing: "5:10 PM",
    remarks: "Closed",
    completedTime: "5:10 PM",
    completedDate: "01-07-2026",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Re: Raja Spiritual Private Limited (Retail Sales team training) - SSDN Technologies",
    timing: "5:19 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "RE: Urgent Request for Training Course Information",
    timing: "6:20 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Re: Saheel Properties (Pre-Sales Training) || SSDN Technologies",
    timing: "6:33 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "Re: Urgent Request for Training Course Information",
    timing: "6:42 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Srishti",
    task: "RE: Kion Group ( OT Security Course (SCADA, PLCs) Training ) || SSDN Technologies",
    timing: "6:45 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "01-07-2026",
    name: "Shivam",
    task: "Re: IBM BAW training Requirement ||",
    timing: "7:11 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Shivam",
    task: "RE: Training request - Citrix DAAS",
    timing: "7:46 AM",
    remarks: "Closed",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Kamal",
    task: "RE: Training+Lab and Extended Lab Requirement | Citrix VDI AVD L2 - AMJ'26",
    timing: "7:49 AM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Kamal",
    task: "RE: MDM Training",
    timing: "08:05",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Srishti",
    task: "PRIMUS Techsystems Private Limited (SAP PS Corporate Trainer ) || SSDN Technologies",
    timing: "11:41 AM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Kamal",
    task: "IBM BAW Training",
    timing: "2:23 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Shivam",
    task: "Managed Services + Content + Labs requirement for Cisco ENAUTO training - Enterprise Customer (Jul'26)",
    timing: "2:28 PM",
    remarks: "Closed",
    completedTime: "2:50 PM",
    completedDate: "02-07-2026",
  },
  {
    date: "02-07-2026",
    name: "Amit",
    task: "Network Cabling Design Training Requirement Support | SSDN Technologies",
    timing: "2:47 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Shivam",
    task: "Re: Lean six sigma black belt- Offline Training Requirement",
    timing: "2:52 PM",
    remarks: "Closed",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Srishti",
    task: "Future Architectural Glass LLC (Future Glass) (Leadership & Supervisory Development Program Training) || SSDN Technologies",
    timing: "3:29 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Kamal",
    task: "Extended Lab Initiation - SCCM+ Intune L2-Module 2 _OND'25",
    timing: "4:09 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Srishti",
    task: "Re: Kion Group ( OT Security Course (SCADA, PLCs) Training ) || SSDN Technologies",
    timing: "4:10 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Kamal",
    task: "Managerial Effectiveness Program || Maharishi Ayurveda x SSDN Technologies ||",
    timing: "4:42 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Amit",
    task: "RE: Exploring Collaboration Opportunities with Kaplan ME",
    timing: "4:45 PM",
    remarks: "Closed",
    completedTime: "5:30 PM",
    completedDate: "02-07-2026",
  },
  {
    date: "02-07-2026",
    name: "Srishti",
    task: "Re: Viva Composite Panel (Posh Training) || SSDN Technologies",
    timing: "5:04 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Srishti",
    task: "Re: Landmark Group ( Cloudflare Training ) || SSDN Technologies",
    timing: "5:19 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Shivam",
    task: "RE: Managed Services + Content + Labs requirement for Cisco ENAUTO training - Enterprise Customer (Jul'26)",
    timing: "5:23 PM",
    remarks: "Closed",
    completedTime: "6:07 PM",
    completedDate: "02-07-2026",
  },
  {
    date: "02-07-2026",
    name: "Srishti",
    task: "Re: Intellectt Inc ( AI & Generative AI Training )- SSDN Technologies",
    timing: "5:47 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Kamal",
    task: "Corporate Grooming & Corporate Readiness Training Program || GD Goenka x SSDN Technologies",
    timing: "6:14 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Kamal",
    task: "Training request - Citrix DAAS",
    timing: "6:30 PM",
    remarks: "CALL",
    completedTime: "6:50 PM",
    completedDate: "02-07-2026",
  },
  {
    date: "02-07-2026",
    name: "Kamal",
    task: "RE: Extended Lab Initiation - SCCM+ Intune L2-Module 2 _OND'25",
    timing: "6:31 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Shivam",
    task: "Re: Cyber Security Awareness Month Program",
    timing: "6:59 PM",
    remarks: "Reply (Shivam)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "02-07-2026",
    name: "Kamal",
    task: "RE: Training request - Citrix DAAS",
    timing: "7:32 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "BluSwap ( Soft Skills Training ) || SSDN Technologies",
    timing: "10:39 AM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Amit",
    task: "Re: AI Trainer Support & Collaboration Opportunity",
    timing: "11:00 AM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Shivam",
    task: "RE: Training+Lab and Extended Lab Requirement | Intune L2 - AMJ'26",
    timing: "12:01 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Re: Tender",
    timing: "12:14 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Business Collaboration Opportunity with SSDN Technologies",
    timing: "12:16 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Amit",
    task: "Leadership Development Training Discussion | 3 July 2026 | 11:00 AM (Dubai Time | SSDN Technologies GS",
    timing: "12:30 PM",
    remarks: "CALL",
    completedTime: "12:45 PM",
    completedDate: "03-07-2026",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Re: Meeting Request to Discuss Our Ongoing Partnership - SSDN Technologies",
    timing: "12:49 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Re: Jerico Technologies ( Networking Training ) – SSDN Technologies",
    timing: "1:20 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Amit",
    task: "Re: Exploring a Learning & Development Collaboration Opportunity with Marriott Hotels",
    timing: "1:28 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Shivam",
    task: "Re: Exploring a Learning & Development Collaboration Opportunity with Marriott Hotels",
    timing: "1:33 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Re: [External] Re: Buckman Laboratories ( Lean six sigma black belt ) – SSDN Technologies",
    timing: "1:43 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Re: Proposal : Questionnaire_RE: SSDN Technologies_Beyond Codes Discussion",
    timing: "1:45 PM",
    remarks: "Closed",
    completedTime: "1:45 PM",
    completedDate: "03-07-2026",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Discussion Meeting with Hawksford || SSDN Technologies",
    timing: "2:00 PM",
    remarks: "CALL",
    completedTime: "2:30 PM",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Introducing Excellence Through Empowerment Program || UCB x SSDN Technologies ||",
    timing: "2:20 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Re: Jerico Technologies ( Networking Training ) – SSDN Technologies",
    timing: "2:51 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Mukesh",
    task: "Re: Partner Opportunity: Reduced Certification Costs & Enhanced Training Programs",
    timing: "3:16 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Shivam",
    task: "Re: Urgent Requirement – Zafran Training (VILT)",
    timing: "3:20 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Shivam",
    task: "Re: Confirmation on SCCM Training || Offline - Sri Lanka",
    timing: "3:49 PM",
    remarks: "Closed",
    completedTime: "6:31 PM",
    completedDate: "03-07-2026",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Re: [ENQUIRY] Hawksford ( Microsoft Copilot Training ) || SSDN Technologies",
    timing: "3:49 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Re: Landmark Group ( Cloudflare Training ) || SSDN Technologies",
    timing: "3:58 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Training request - Citrix DAAS",
    timing: "4:03 PM",
    remarks: "Closed",
    completedTime: "6:16 PM",
    completedDate: "03-07-2026",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Re: Jerico Technologies ( Networking Training ) – SSDN Technologies",
    timing: "4:05 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Posh Training x SSDN Technologies || Offline || Noida ||",
    timing: "4:05 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Training request - Citrix DAAS",
    timing: "4:05 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Introducing Excellence Through Empowerment Program || SSDN Technologies ||",
    timing: "4:12 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Re: Kion Group ( OT Security Course (SCADA, PLCs) Training ) || SSDN Technologies",
    timing: "4:49 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Shivam",
    task: "Re: ITIL Version 5 Foundation",
    timing: "5:28 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: VT Requirement_Lucknow & Madurai || Professional",
    timing: "5:35 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Quote for CSAM'26",
    timing: "5:35 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: PR725073 - PANW XSIAM Certifications Vouchers",
    timing: "5:38 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "5+D80:54 PM",
    timing: "5:39 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Request for Training Session – TechBee HR Team",
    timing: "5:42 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Trainer profile required Karan Singh <karan.s@hcltech.com> | OCI IAM Cloud Training - Instructor Led | BRP | OEM",
    timing: "5:43 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Hydraulics & CATIA V5 training",
    timing: "5:44 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Soft Skills Training Program || AAR One x SSDN Technologies ||",
    timing: "5:47 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Proposal for Enterprise AI Workforce Transformation for HCLTech",
    timing: "5:48 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Omnissa Workspace One from our client Cognizant.",
    timing: "5:50 PM",
    remarks: "In-Process",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Request for AWS Programs and Pricing(GPS)",
    timing: "5:51 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Srishti",
    task: "Business Collaboration Opportunity with SSDN Technologies",
    timing: "5:52 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Shivam",
    task: "RE: Vendor / staffing needs - Ai Awareness",
    timing: "5:54 PM",
    remarks: "Closed",
    completedTime: "5:54 PM",
    completedDate: "03-07-2026",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: License requirement for enterprise customer training program - ISTQB CT-GenAI (Jul'26)",
    timing: "5:56 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
  {
    date: "03-07-2026",
    name: "Kamal",
    task: "Re: Managed Services + Content + Labs requirement for Cisco NIOS DDI Operations, Administration & Deployment training - Enterprise Customer (Jul'26)",
    timing: "5:57 PM",
    remarks: "Pending (Awaiting Client)",
    completedTime: "",
    completedDate: "",
  },
];

function App() {
  const [tasks, setTasks] = useState([]);
  const [recentTasks, setRecentTasks] = useState([]);

  const fetchTasks = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/tasks");

      const allTasks = [...initialTasks, ...response.data];

      setTasks(allTasks);

      // Latest 5 tasks
      setRecentTasks([...allTasks].slice(-5).reverse());
    } catch (err) {
      console.log(err);

      setTasks(initialTasks);
      setRecentTasks([...initialTasks].slice(-5).reverse());
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <Router>
      <div className="app-container">
        <Sidebar />

        <main className="main-content">
          <Routes>
            <Route
              path="/"
              element={<Navigate to="/dashboard" replace />}
            />

            <Route
              path="/dashboard"
              element={
                <Dashboard
                  tasks={tasks}
                  setTasks={setTasks}
                  recentTasks={recentTasks}
                  setRecentTasks={setRecentTasks}
                  fetchTasks={fetchTasks}
                />
              }
            />

            <Route
              path="/operation"
              element={
                <Operation
                  tasks={tasks}
                  setTasks={setTasks}
                  fetchTasks={fetchTasks}
                />
              }
            />

            <Route
              path="/analytics"
              element={<Analytics tasks={tasks} />}
            />

            <Route
              path="/team"
              element={<Team tasks={tasks} />}
            />

            <Route
  path="/profile"
  element={<Profile tasks={tasks} />}
/>

<Route
  path="/profile/:name"
  element={<Profile tasks={tasks} />}
/>
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;