import React, { useState } from "react";
import axios from "axios";
import "../assets/css/dashboard.css";
import logo from "../assets/ssdn-logo.png"; // Aapke assets folder ka path

const Dashboard = () => {
  const [taskData, setTaskData] = useState({
    date: "", name: "Amit", status: "Pending", 
    details: "", startTime: "", endDate: "", endTime: ""
  });
  const [taskHistory, setTaskHistory] = useState([]);

  const handleChange = (e) => {
    setTaskData({ ...taskData, [e.target.name]: e.target.value });
  };

  const handleAppend = async () => {
    // Basic Validation
    if (!taskData.date || !taskData.details || !taskData.startTime) {
      alert("Please fill required fields");
      return;
    }
    setTaskHistory([taskData, ...taskHistory]);
    setTaskData({ date: "", name: "Amit", status: "Pending", details: "", startTime: "", endDate: "", endTime: "" });
  };

  return (
    <div className="dashboard-wrapper">
     

      <main className="main-panel">
        <header className="top-header">
          <h1>MASTER SPREADSHEET</h1>
          <img src={logo} alt="SSDN Logo" className="header-logo" />
        </header>

        <section className="task-form-box">
          <h2>Add New Task</h2>
          <div className="form-grid">
            <div className="input-group"><label>Date</label><input type="date" name="date" value={taskData.date} onChange={handleChange} /></div>
            <div className="input-group"><label>Name</label><select name="name" value={taskData.name} onChange={handleChange}><option>Amit</option><option>Shivam</option></select></div>
            <div className="input-group"><label>Status</label><select name="status" value={taskData.status} onChange={handleChange}><option>Pending</option><option>Closed</option><option>Calls</option></select></div>
            <div className="input-group"><label>Strategic Details</label><input type="text" name="details" placeholder="Enter task details..." value={taskData.details} onChange={handleChange} /></div>
            <div className="input-group"><label>Start Time</label><input type="time" name="startTime" value={taskData.startTime} onChange={handleChange} /></div>
            
            {/* Conditional Fields */}
            {(taskData.status === "Closed" || taskData.status === "Calls") && (
              <>
                <div className="input-group"><label>End Date</label><input type="date" name="endDate" value={taskData.endDate} onChange={handleChange} /></div>
                <div className="input-group"><label>End Time</label><input type="time" name="endTime" value={taskData.endTime} onChange={handleChange} /></div>
              </>
            )}
          </div>
          <button className="submit-btn" onClick={handleAppend}>Append Task</button>
        </section>

        <section className="history-box">
          <h2>Daily Task History</h2>
          <table className="styled-table">
            <thead><tr><th>Date</th><th>Name</th><th>Task</th><th>Status</th><th>Start Time</th></tr></thead>
            <tbody>{taskHistory.map((t, i) => <tr key={i}><td>{t.date}</td><td>{t.name}</td><td>{t.details}</td><td>{t.status}</td><td>{t.startTime}</td></tr>)}</tbody>
          </table>
        </section>
      </main>
    </div>
  );
};
export default Dashboard;