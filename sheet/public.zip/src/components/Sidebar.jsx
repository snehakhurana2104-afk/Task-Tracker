import React from "react";



import {



  LayoutGrid,



  ClipboardList,



  Users,



  BarChart3,



} from "lucide-react";



import { NavLink } from "react-router-dom";



import logo from "../assets/ssdn-logo.png";







const Sidebar = () => {



  return (



    <div className="sidebar">







      {/* Logo */}



      <div className="logo-section">



        <img src={logo} alt="SSDN Logo" className="sidebar-logo" />







        <h2 className="sidebar-title">



          



          <span> Task System Management</span>



        </h2>







        



      </div>







      {/* Menu */}







      <NavLink



        to="/dashboard"



        className={({ isActive }) =>



          isActive ? "nav-item active" : "nav-item"



        }



      >



        <LayoutGrid size={20} />



        <span>Dashboard</span>



      </NavLink>







      <NavLink



        to="/operation"



        className={({ isActive }) =>



          isActive ? "nav-item active" : "nav-item"



        }



      >



        <ClipboardList size={20} />



        <span>Operation</span>



      </NavLink>







      <NavLink



        to="/team"



        className={({ isActive }) =>



          isActive ? "nav-item active" : "nav-item"



        }



      >



        <Users size={20} />



        <span>Team</span>



      </NavLink>







      <NavLink



        to="/analytics"



        className={({ isActive }) =>



          isActive ? "nav-item active" : "nav-item"



        }



      >



        <BarChart3 size={20} />



        <span>Analytics</span>



      </NavLink>







    </div>



  );



};







export default Sidebar;