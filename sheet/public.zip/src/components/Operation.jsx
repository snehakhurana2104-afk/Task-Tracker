import React, { useState } from "react";
import axios from "axios";
import "../assets/css/operation.css";
import logo from "../assets/ssdn-logo.png";

const Operation = ({ tasks, setTasks, fetchTasks }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({});

  // Filter Logic
  const filteredTasks = tasks.filter((task) =>
    Object.values(task).some((val) =>
      String(val).toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const startEdit = (task) => {
    setEditingId(task._id);
    setEditData({ ...task });
  };

  const saveEdit = async () => {
    try {
      await axios.put(`http://localhost:5000/api/tasks/${editData._id}`, editData);
      alert("Task Updated Successfully");
      fetchTasks();
      setEditingId(null);
    } catch (err) {
      alert("Update Failed");
    }
  };

  const deleteTask = async (id) => {
    if (!window.confirm("Are you sure you want to delete?")) return;
    try {
      await axios.delete(`http://localhost:5000/api/tasks/${id}`);
      fetchTasks();
    } catch (err) {
      alert("Delete Failed");
    }
  };

  return (
    <div className="operations-page">
      <div className="operations-header">
        <div>
          <h2 className="operations-title">Current Tasks</h2>
          <input
            type="text"
            className="search-box"
            placeholder="Search tasks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <img src={logo} alt="Logo" className="operations-logo" />
      </div>

      <div className="operations-card">
        <table className="task-table">
          <thead>
            <tr>
              <th>S.No</th><th>Date</th><th>Name</th><th>Task</th>
              <th>Timing</th><th>Remarks</th><th>Comp. Time</th>
              <th>Comp. Date</th><th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredTasks.length > 0 ? (
              filteredTasks.map((task, index) => (
                <tr key={task._id}>
                  <td>{index + 1}</td>
                  {editingId === task._id ? (
                    <>
                      <td><input type="date" value={editData.date} onChange={(e) => setEditData({...editData, date: e.target.value})} /></td>
                      <td><input type="text" value={editData.name} onChange={(e) => setEditData({...editData, name: e.target.value})} /></td>
                      <td><input type="text" value={editData.task} onChange={(e) => setEditData({...editData, task: e.target.value})} /></td>
                      <td><input type="time" value={editData.timing} onChange={(e) => setEditData({...editData, timing: e.target.value})} /></td>
                      <td><input type="text" value={editData.remarks} onChange={(e) => setEditData({...editData, remarks: e.target.value})} /></td>
                      <td><input type="time" value={editData.completedTime} onChange={(e) => setEditData({...editData, completedTime: e.target.value})} /></td>
                      <td><input type="date" value={editData.completedDate} onChange={(e) => setEditData({...editData, completedDate: e.target.value})} /></td>
                      <td><button className="btn-save" onClick={saveEdit}>Save</button></td>
                    </>
                  ) : (
                    <>
                      <td>{task.date}</td>
                      <td>{task.name}</td>
                      <td>{task.task}</td>
                      <td>{task.timing}</td>
                      <td>{task.remarks}</td>
                      <td>{task.completedTime || "-"}</td>
                      <td>{task.completedDate || "-"}</td>
                      <td>
                        <button className="btn-edit" onClick={() => startEdit(task)}>Edit</button>
                        <button className="btn-delete" onClick={() => deleteTask(task._id)}>Delete</button>
                      </td>
                    </>
                  )}
                </tr>
              ))
            ) : (
              <tr><td colSpan="9" style={{textAlign:"center"}}>No Tasks Found</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Operation;