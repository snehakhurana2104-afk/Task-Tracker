import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import "../assets/css/profile.css";

export default function Profile({ tasks }) {
  const { name } = useParams();
  const navigate = useNavigate();

  // Selected member tasks
  const memberTasks = tasks.filter(
    (item) => item.name.toLowerCase() === name.toLowerCase()
  );

  const totalTasks = memberTasks.length;

  const closed = memberTasks.filter(
    (t) => t.remarks?.toLowerCase() === "closed"
  ).length;

  const inProcess = memberTasks.filter(
    (t) =>
      t.remarks?.toLowerCase() === "in-process" ||
      t.remarks?.toLowerCase() === "in process"
  ).length;

  const pending = memberTasks.filter((t) =>
    t.remarks?.toLowerCase().includes("pending")
  ).length;

  return (
      <div className="profile-header">

  <button
    className="back-btn"
    onClick={() => navigate("/team")}
  >
    ← Back
  </button>

  <div className="profile-title">
    <h2>{name}'s Profile</h2>
    <p>Employee Task Performance Dashboard</p>
  </div>


        
    

      <div className="profile-summary">

        <div className="summary-card total-card">
          <h3>{totalTasks}</h3>
          <p>Total Tasks</p>
        </div>

        <div className="summary-card closed-card">
          <h3>{closed}</h3>
          <p>Closed</p>
        </div>

        <div className="summary-card process-card">
          <h3>{inProcess}</h3>
          <p>In Process</p>
        </div>

        <div className="summary-card pending-card">
          <h3>{pending}</h3>
          <p>Pending</p>
        </div>

      </div>

      {/* Task Table */}

      <div className="operations-card">

        <div className="table-title">
          <h3>Task History</h3>
        </div>

        <table className="task-table">

          <thead>
            <tr>
              <th>S.No</th>
              <th>Date</th>
              <th>Task</th>
              <th>Timing</th>
              <th>Status</th>
              <th>Completed Time</th>
              <th>Completed Date</th>
            </tr>
          </thead>

          <tbody>

            {memberTasks.length > 0 ? (

              memberTasks.map((task, index) => (

                <tr key={task._id || index}>

                  <td>{index + 1}</td>

                  <td>{task.date}</td>

                  <td>{task.task}</td>

                  <td>{task.timing}</td>

                  <td>
                    <span
                      className={`status-badge ${
                        task.remarks?.toLowerCase() === "closed"
                          ? "closed"
                          : task.remarks?.toLowerCase().includes("pending")
                          ? "pending"
                          : "process"
                      }`}
                    >
                      {task.remarks}
                    </span>
                  </td>

                  <td>{task.completedTime || "-"}</td>

                  <td>{task.completedDate || "-"}</td>

                </tr>

              ))

            ) : (

              <tr>
                <td
                  colSpan="7"
                  style={{
                    textAlign: "center",
                    padding: "30px",
                    color: "#6b7280"
                  }}
                >
                  No Tasks Found
                </td>
              </tr>

            )}

          </tbody>

        </table>

      </div>

    </div>
  );
}