import React from "react";
import "../assets/css/analytics.css";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import logo from "../assets/ssdn-logo.png";

const Analytics = ({ tasks = [] }) => {

  // ===============================
  // Dashboard Cards
  // ===============================

  const totalTasks = tasks.length;

  const closedTasks = tasks.filter(
    (task) =>
      task.remarks &&
      task.remarks.toLowerCase().includes("closed")
  ).length;

  const pendingTasks = tasks.filter(
    (task) =>
      task.remarks &&
      task.remarks.toLowerCase().includes("pending")
  ).length;

  const inProcessTasks = tasks.filter(
    (task) =>
      task.remarks &&
      task.remarks.toLowerCase().includes("in-process")
  ).length;

  const callTasks = tasks.filter(
    (task) =>
      task.remarks &&
      task.remarks.toLowerCase().includes("call")
  ).length;

  const replyTasks = tasks.filter(
    (task) =>
      task.remarks &&
      (
        task.remarks.toLowerCase().includes("reply") ||
        task.remarks.toLowerCase().includes("respond") ||
        task.remarks.toLowerCase().includes("solution")
      )
  ).length;

  // ===============================
  // Status Chart Data
  // ===============================

  const statusData = [
    {
      name: "Pending (Awaiting Client)",
      value: pendingTasks,
    },
    {
      name: "In Process",
      value: inProcessTasks,
    },
    {
      name: "Closed",
      value: closedTasks,
    },
    {
      name: "Call",
      value: callTasks,
    },
    {
      name: "Reply",
      value: replyTasks,
    },
  ];
   // Employee Wise Data

const employeeMap = {};

tasks.forEach((task) => {
  const name = task.name || "Unknown";
  employeeMap[name] = (employeeMap[name] || 0) + 1;
});

const employeeData = Object.keys(employeeMap).map((key) => ({
  name: key,
  tasks: employeeMap[key],
}));
  const COLORS = [
    "#ff9800",
    "#03a9f4",
    "#4caf50",
    "#9c27b0",
    "#f44336",
  ];

  return (
  <div className="analytics-page">

    <div className="analytics-header">
        <h1 className="analytics-title">
            Analytics Dashboard
        </h1>

        <img
            src={logo}
            alt="SSDN"
            className="analytics-logo"
        />
    </div>

      {/* ===========================
            Summary Cards
      =========================== */}

      <div className="summary-cards">

        <div className="card">
          <h4>Total Tasks</h4>
          <h2>{totalTasks}</h2>
        </div>

        <div className="card">
          <h4>Pending (Awaiting Client)</h4>
          <h2>{pendingTasks}</h2>
        </div>

        <div className="card">
          <h4>In Process</h4>
          <h2>{inProcessTasks}</h2>
        </div>

        <div className="card">
          <h4>Closed</h4>
          <h2>{closedTasks}</h2>
        </div>

        <div className="card">
          <h4>Calls</h4>
          <h2>{callTasks}</h2>
        </div>

        <div className="card">
          <h4>Reply / Solution</h4>
          <h2>{replyTasks}</h2>
        </div>

      </div>

            {/* ===========================
            Charts Row
      =========================== */}

      {/* Employee Wise Data */}
      {(() => {
        const employeeMap = {};

        tasks.forEach((task) => {
          const name = task.name || "Unknown";

          employeeMap[name] = (employeeMap[name] || 0) + 1;
        });
       

        return (
          <div className="charts-row">

            {/* Pie Chart */}

            <div className="chart-box">

              <h3>Status Wise Tasks</h3>

              <ResponsiveContainer width="100%" height={320}>

                <PieChart>

                  <Pie
                    data={statusData}
                    dataKey="value"
                    cx="50%"
                    cy="50%"
                    outerRadius={110}
                    label
                  >

                    {statusData.map((entry, index) => (
                      <Cell
                        key={index}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}

                  </Pie>

                  <Tooltip />

                  <Legend />

                </PieChart>

              </ResponsiveContainer>

            </div>

            {/* Employee Bar Chart */}

            <div className="chart-box">

              <h3>Employee Performance</h3>

              <ResponsiveContainer width="100%" height={320}>

                <BarChart data={employeeData}>

                  <CartesianGrid strokeDasharray="3 3" />

                  <XAxis dataKey="name" />

                  <YAxis />

                  <Tooltip />

                  <Legend />

                  <Bar
                    dataKey="tasks"
                    fill="#2563eb"
                  />

                </BarChart>

              </ResponsiveContainer>

            </div>

          </div>
        );
      })()}
            {/* ===========================
            Date Wise Chart
      =========================== */}

      {(() => {
        const dateMap = {};

        tasks.forEach((task) => {
          const date = task.date || "Unknown";

          dateMap[date] = (dateMap[date] || 0) + 1;
        });

        const dateData = Object.keys(dateMap).map((key) => ({
          date: key,
          tasks: dateMap[key],
        }));

        return (
          <div className="charts-row">

            <div className="chart-box">

              <h3>Date Wise Tasks</h3>

              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dateData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar
                    dataKey="tasks"
                    fill="#10b981"
                  />
                </BarChart>
              </ResponsiveContainer>

            </div>

            {/* Pending Employee Table */}

            <div className="chart-box">

              <h3>Employee Task Summary</h3>

              <table className="analytics-table">

                <thead>
                  <tr>
                    <th>Employee</th>
                    <th>Total Tasks</th>
                  </tr>
                </thead>

                <tbody>

                  {employeeData.map((emp, index) => (

                    <tr key={index}>
                      <td>{emp.name}</td>
                      <td>{emp.tasks}</td>
                    </tr>

                  ))}

                </tbody>

              </table>

            </div>

          </div>
        );

      })()}

      {/* ===========================
            Recent Activity
      =========================== */}

      <div className="recent-activity">

        <h3>Recent Activities</h3>

        <table className="analytics-table">

          <thead>

            <tr>

              <th>Date</th>
              <th>Employee</th>
              <th>Task</th>
              <th>Status</th>

            </tr>

          </thead>

          <tbody>

            {tasks.slice(-8).reverse().map((task, index) => (

              <tr key={index}>

                <td>{task.date}</td>

                <td>{task.name}</td>

                <td>{task.task}</td>

                <td>{task.remarks}</td>

              </tr>

            ))}

          </tbody>

        </table>

      </div>

    </div>
  );
};

export default Analytics;