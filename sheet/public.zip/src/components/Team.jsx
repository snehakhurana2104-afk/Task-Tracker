import { useNavigate } from "react-router-dom";
import "../assets/css/team.css";
import logo from "../assets/ssdn-logo.png";
export default function Team({ tasks }) {
  const navigate = useNavigate();

  const colors = [
    "#4F46E5",
    "#22C55E",
    "#F97316",
    "#A855F7",
    "#EC4899",
    "#3B82F6",
    "#EF4444",
  ];

  const members = [...new Set(tasks.map((task) => task.name))].map(
    (name, index) => ({
      name,
      color: colors[index % colors.length],
      totalTasks: tasks.filter((t) => t.name === name).length,
    })
  );
 
  return (
    <div className="team-page">

      {/* Header */}

      <div className="team-header">

        <div className="team-title">
          <h2>Team Performance Overview</h2>
          <p>Employee Performance & Task Monitoring</p>
        </div>
         <img
    src={logo}
    alt="SSDN Logo"
    className="team-logo"
  />
      </div>

      {/* Cards */}

      <div className="team-grid">

        {members.map((member) => (

          <div className="team-card" key={member.name}>

            <div
              className="team-avatar"
              style={{ backgroundColor: member.color }}
            >
              {member.name.charAt(0).toUpperCase()}
            </div>

            <h3>{member.name}</h3>

            <div className="task-box">
              <span>Total Tasks</span>
              <h4>{member.totalTasks}</h4>
            </div>

            <button
              className="view-btn"
              onClick={() => navigate(`/profile/${member.name}`)}
            >
              View Profile
            </button>

          </div>

        ))}

      </div>

    </div>
  );
}